package com.hoangsonpc.springbootapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
